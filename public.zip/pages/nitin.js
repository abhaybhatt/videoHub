const nitin = () => {
    return(
        <div>Fuck boiii</div>
    )
}

export default nitin